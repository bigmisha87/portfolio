// Create a dialog box for user input
var dialog = new Window("dialog", "Composition Settings");
dialog.alignChildren = "left";

// Add input fields for image path, composition size, number of images, and duration
var imageGroup = dialog.add("group");
imageGroup.add("statictext", undefined, "Image Path:");
var imagePathInput = imageGroup.add("edittext", undefined, "C:\\Users\\bigde\\Desktop\\images");
imagePathInput.characters = 30;

var compSizeGroup = dialog.add("group");
compSizeGroup.add("statictext", undefined, "Composition Size:");
var compWidthInput = compSizeGroup.add("edittext", undefined, "1024");
compWidthInput.characters = 5;
compSizeGroup.add("statictext", undefined, "x");
var compHeightInput = compSizeGroup.add("edittext", undefined, "1024");
compHeightInput.characters = 5;

var numImagesGroup = dialog.add("group");
numImagesGroup.add("statictext", undefined, "Number of Images:");
var numImagesInput = numImagesGroup.add("edittext", undefined, "5");
numImagesInput.characters = 5;

var durationGroup = dialog.add("group");
durationGroup.add("statictext", undefined, "Duration (seconds):");
var durationInput = durationGroup.add("edittext", undefined, "10");
durationInput.characters = 5;

// Add buttons for OK and Cancel
var buttonGroup = dialog.add("group");
var okButton = buttonGroup.add("button", undefined, "OK");
var cancelButton = buttonGroup.add("button", undefined, "Cancel");

// Set default values for image path, composition size, number of images, and duration
imagePathInput.text = "C:\\Users\\bigde\\Desktop\\images";
compWidthInput.text = "1024";
compHeightInput.text = "1024";
numImagesInput.text = "5";
durationInput.text = "10";

// Function to create the composition
function createComposition() {
    var imageFolderPath = imagePathInput.text;
    var compositionWidth = parseInt(compWidthInput.text);
    var compositionHeight = parseInt(compHeightInput.text);
    var numImages = parseInt(numImagesInput.text);
    var compositionDuration = parseInt(durationInput.text);

    // Create a new composition with square pixel aspect ratio
    var comp = app.project.items.addComp("My Composition", compositionWidth, compositionHeight, 1.0, compositionDuration, 30);

    // Create a null layer to parent the images
    var nullLayer = comp.layers.addNull();
    nullLayer.name = "Parent Null";

    // Create an array to store the image layers
    var imageLayers = [];

    // Loop through the images and add them to the composition
    for (var i = 1; i <= numImages; i++) {
        var imageName = i.toString();
        var imageFilePath = imageFolderPath + "\\" + imageName + ".png";

        // Import the image file
        var importedFile = app.project.importFile(new ImportOptions(File(imageFilePath)));

        // Create a new layer for the image
        var imageLayer = comp.layers.add(importedFile);
        imageLayer.name = "Image " + i;

        // Set the layer's in point to the start of the composition
        imageLayer.inPoint = 0;

        // Set the layer's out point to the end of the composition
        imageLayer.outPoint = comp.duration;

        // Scale the image layer
        var scaleProperty = imageLayer.property("Scale");
        var scale = Math.pow(2, i - 1) * 100; // Calculate the scale based on the index of the image
        scaleProperty.setValue([scale, scale]);

        // Parent the image layer to the null layer
        imageLayer.parent = nullLayer;

        // Add the image layer to the array
        imageLayers.push(imageLayer);
    }

    // Alert when the composition is ready
    alert("Composition created!");

    // Display the composition in the viewer
    comp.openInViewer();

    // Reverse the order of all layers
    var numLayers = comp.layers.length;
    for (var j = 1; j <= numLayers; j++) {
        comp.layers[j].moveToBeginning();
    }

    // Add masks to each image layer
    for (var k = 0; k < imageLayers.length; k++) {
        var imageLayer = imageLayers[k];

        // Create a new mask on the layer
        var maskProperty = imageLayer.property("Masks");
        var newMask = maskProperty.addProperty("Mask");

        // Set the mask path to the layer dimensions
        var maskPath = newMask.property("maskPath");
        var maskShape = new Shape();
        maskShape.vertices = [
            [0, 0],
            [imageLayer.width, 0],
            [imageLayer.width, imageLayer.height],
            [0, imageLayer.height]
        ];
        maskPath.setValue(maskShape);

        // Set the mask feather and expansion properties
        newMask.property("Mask Feather").setValue([100, 100]);
        newMask.property("Mask Expansion").setValue(-100);
    }

    // Alert when masks are added to the layers
    alert("Masks added to image layers!");
}

// Event listener for OK button
okButton.onClick = function() {
    dialog.close();
    createComposition();
};

// Event listener for Cancel button
cancelButton.onClick = function() {
    dialog.close();
};

// Show the dialog box
dialog.show();
