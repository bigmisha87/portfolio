// Create a custom dialog with bullet-point options
var dialog = new Window("dialog", "Modify Layer Names");
dialog.orientation = "column";

var actionGroup = dialog.add("group");
actionGroup.orientation = "column";

var findReplaceButton = actionGroup.add("button", undefined, "Find and Replace");
var addSuffixButton = actionGroup.add("button", undefined, "Add Suffix");
var addPrefixButton = actionGroup.add("button", undefined, "Add Prefix");
var newFormatButton = actionGroup.add("button", undefined, "Define New Format");

// Add event listeners to buttons
findReplaceButton.onClick = function() {
    dialog.close();
    performAction("find_replace");
};
addSuffixButton.onClick = function() {
    dialog.close();
    performAction("add_suffix");
};
addPrefixButton.onClick = function() {
    dialog.close();
    performAction("add_prefix");
};
newFormatButton.onClick = function() {
    dialog.close();
    performAction("new_format");
};

dialog.show();

// Perform the selected action
function performAction(action) {
    var layers = app.activeDocument.layers;
    var counter = 1;

    switch (action) {
        case "find_replace":
            var findText = prompt("Enter text to find:", "");
            var replaceText = prompt("Enter text to replace with:", "");

            for (var i = 0; i < layers.length; i++) {
                var currentLayer = layers[i];
                var newLayerName = currentLayer.name.replace(new RegExp(findText, 'g'), replaceText);
                currentLayer.name = newLayerName;
            }

            alert("Layer names have been modified using find and replace.");
            break;

        case "add_suffix":
            var suffix = prompt("Enter the suffix to add:", "");

            for (var i = 0; i < layers.length; i++) {
                var currentLayer = layers[i];
                var newLayerName = currentLayer.name + suffix;
                currentLayer.name = newLayerName;
            }

            alert("Suffix added to layer names.");
            break;

        case "add_prefix":
            var prefix = prompt("Enter the prefix to add:", "");

            for (var i = 0; i < layers.length; i++) {
                var currentLayer = layers[i];
                var newLayerName = prefix + currentLayer.name;
                currentLayer.name = newLayerName;
            }

            alert("Prefix added to layer names.");
            break;

        case "new_format":
            var baseName = prompt("Enter the base name for the format:", "");

            for (var i = 0; i < layers.length; i++) {
                var currentLayer = layers[i];
                var newLayerName = baseName + "_" + counter;
                currentLayer.name = newLayerName;
                counter++;
            }

            alert("Layer names have been updated with a new format.");
            break;

        default:
            alert("Invalid action. Operation cancelled.");
            break;
    }
}
